﻿CREATE TABLE [dbo].[Employee]
(
	[Username] VARCHAR NOT NULL PRIMARY KEY, 
    [Name] NCHAR(10) NULL, 
    [DOB] NCHAR(10) NULL, 
    [Password] NCHAR(10) NULL
)
