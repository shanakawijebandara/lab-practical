﻿CREATE TABLE [dbo].[Contact Details
]
(
	[Username] INT NOT NULL PRIMARY KEY, 
    [Email] NCHAR(10) NULL, 
    [Address] NCHAR(10) NULL, 
    [Contact No] NCHAR(10) NULL
)
