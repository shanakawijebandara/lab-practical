﻿namespace Question_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.fnTextBox = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.SignUp_Click = new System.Windows.Forms.Button();
            this.Reset_Click = new System.Windows.Forms.Button();
            this.LnTextBox = new System.Windows.Forms.TextBox();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.UsernameTextBox = new System.Windows.Forms.TextBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.ConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.Dob = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(54, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "First Name";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(54, 140);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 22);
            this.button2.TabIndex = 1;
            this.button2.Text = "Last Name";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(54, 188);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Date Of Birth";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(54, 232);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Email";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(54, 280);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(136, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Username";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(54, 324);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(136, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "Password";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(54, 375);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(136, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "Confirm Password";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // fnTextBox
            // 
            this.fnTextBox.Location = new System.Drawing.Point(257, 92);
            this.fnTextBox.Name = "fnTextBox";
            this.fnTextBox.Size = new System.Drawing.Size(228, 22);
            this.fnTextBox.TabIndex = 7;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(199, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(118, 41);
            this.button8.TabIndex = 14;
            this.button8.Text = "Sign Up";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // SignUp_Click
            // 
            this.SignUp_Click.Location = new System.Drawing.Point(519, 396);
            this.SignUp_Click.Name = "SignUp_Click";
            this.SignUp_Click.Size = new System.Drawing.Size(91, 42);
            this.SignUp_Click.TabIndex = 15;
            this.SignUp_Click.Text = "Sign Up";
            this.SignUp_Click.UseVisualStyleBackColor = true;
            this.SignUp_Click.Click += new System.EventHandler(this.button9_Click);
            // 
            // Reset_Click
            // 
            this.Reset_Click.Location = new System.Drawing.Point(649, 396);
            this.Reset_Click.Name = "Reset_Click";
            this.Reset_Click.Size = new System.Drawing.Size(96, 42);
            this.Reset_Click.TabIndex = 16;
            this.Reset_Click.Text = "Reset";
            this.Reset_Click.UseVisualStyleBackColor = true;
            this.Reset_Click.Click += new System.EventHandler(this.Reset_Click_Click);
            // 
            // LnTextBox
            // 
            this.LnTextBox.Location = new System.Drawing.Point(257, 140);
            this.LnTextBox.Name = "LnTextBox";
            this.LnTextBox.Size = new System.Drawing.Size(228, 22);
            this.LnTextBox.TabIndex = 17;
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Location = new System.Drawing.Point(257, 233);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(228, 22);
            this.EmailTextBox.TabIndex = 19;
            // 
            // UsernameTextBox
            // 
            this.UsernameTextBox.Location = new System.Drawing.Point(257, 280);
            this.UsernameTextBox.Name = "UsernameTextBox";
            this.UsernameTextBox.Size = new System.Drawing.Size(228, 22);
            this.UsernameTextBox.TabIndex = 20;
            this.UsernameTextBox.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(257, 325);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PasswordChar = '*';
            this.PasswordTextBox.Size = new System.Drawing.Size(228, 22);
            this.PasswordTextBox.TabIndex = 21;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.PasswordTextBox_TextChanged);
            // 
            // ConfirmPasswordTextBox
            // 
            this.ConfirmPasswordTextBox.Location = new System.Drawing.Point(257, 375);
            this.ConfirmPasswordTextBox.Name = "ConfirmPasswordTextBox";
            this.ConfirmPasswordTextBox.PasswordChar = '*';
            this.ConfirmPasswordTextBox.Size = new System.Drawing.Size(228, 22);
            this.ConfirmPasswordTextBox.TabIndex = 22;
            // 
            // Dob
            // 
            this.Dob.Location = new System.Drawing.Point(257, 188);
            this.Dob.Name = "Dob";
            this.Dob.Size = new System.Drawing.Size(228, 22);
            this.Dob.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Dob);
            this.Controls.Add(this.ConfirmPasswordTextBox);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.UsernameTextBox);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.LnTextBox);
            this.Controls.Add(this.Reset_Click);
            this.Controls.Add(this.SignUp_Click);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.fnTextBox);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox fnTextBox;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button SignUp_Click;
        private System.Windows.Forms.Button Reset_Click;
        private System.Windows.Forms.TextBox LnTextBox;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.TextBox UsernameTextBox;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.TextBox ConfirmPasswordTextBox;
        private System.Windows.Forms.DateTimePicker Dob;
    }
}

